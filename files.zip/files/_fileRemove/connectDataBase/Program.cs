﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace connectDataBase
{
    class Program
    {
        static void Main(string[] args)
        {
            Program rd = new Program();
            rd.SimpleRead();
        }


        public void SimpleRead()
        {

            SqlDataReader rdr = null;
            SqlConnection conn = new SqlConnection("Server=TLF-PRD-WBD04.cloudapp.net;Database=db_SISCOB;User ID=a.dasilva;Password=41L70N!$");
            SqlCommand cmd = new SqlCommand("SELECT [DESCRICAO] ,[DESCRICAO_02] ,[DESCRICAO_03]  FROM [DB_SISCOB].[ADM].[TB_APP_CONTROLE]  WHERE [TIPO] = 'LIMPAR_DIRETORIOS' ", conn);

            try
            {
                // open the connection
                conn.Open();

                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    // get the results of each column
                    string diretorio = (string)rdr["DESCRICAO"];
                    //string tipo = (string)rdr["DESCRICAO_02"];
                    //string permanencia = (string)rdr["DESCRICAO_03"];

                    


                    Console.WriteLine(diretorio);


                }
                Console.ReadKey();// enter
                //Console.ReadLine();// entrada de dados

            }

            finally
            {
                // 3. close the reader
                if (rdr != null)
                {
                    rdr.Close();
                }

                // close the connection
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }





    }
}

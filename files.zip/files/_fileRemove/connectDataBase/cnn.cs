﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Data;
//using System.Data.SqlClient;


//namespace connectDataBase
//{

//    class cnn
//    {
//        public string ConnectionString { get; set; }
//        public string query { get; set; }
        
//        public Conectar(string connection_string ){
//            this.ConnectionString = connection_string;
//        }




        
    
//    }
//}

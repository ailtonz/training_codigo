﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exportAcordo
{
    class Acordo
    {
        public string Diretorio { get; set; }
        public string Arquivo { get; set; }
        public string Query { get; set; }
    }
}

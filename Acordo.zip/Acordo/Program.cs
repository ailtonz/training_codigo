﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Text.RegularExpressions;

using System.Data;
using System.Data.SqlClient;

//teste de uso.
namespace exportarAcordo
{
    class Program
    {

        class Acordos
        {

            // propriedades
            private String _procv;
            private String _id;
            private String _nome_analista;
            private String _nome_analista_tmp;
            private String _feedback;
            private String _area_ofensora;
            private String _tipo_pagto;
            private String _dt_pagto;
            private String _valor_pagto;
            private String _dt_ajuste;
            private String _valor_ajustado;
            private String _resumo_executivo_acao;
            private String _resumo_executivo_problema;
            private String _historico_detalhado;
            private String _dt_follow_up;
            private String _dt_encerramento;
            private String _dt_contato;
            private String _responsavel;
            private String _faixa_fornecedor;
            private String _faixa_fecho;
            private String _faixa_arrecada_inicial;
            private String _faixa_arrecada_atual;
            private String _raiz_grupo;
            private String _grupo;
            private String _raiz;
            private String _cnpj;
            private String _nome;
            private String _nome_cliente;
            private String _tipo;
            private String _empresa;
            private String _conta;
            private String _tel;
            private String _local;
            private String _terminal;
            private String _dv;
            private String _nrc;
            private String _classerv;
            private String _titulo;
            private String _filial;
            private String _lj_cli;
            private String _cod_cli;
            private String _documento_sap;
            private String _doc_fat;
            private String _n_doc_de_para_atlys;
            private String _nota_fiscal;
            private String _venc_atual;
            private String _venc_original;
            private String _dt_process;
            private String _anomes;
            private String _dia_vencimento_lote;
            private String _numero_lote;
            private String _valor_lote;
            private String _saldo_car_26;
            private String _saldo_car_30;
            private String _saldo_car_05;
            private String _saldo_car_14;
            private String _saldo_car_21;
            private String _saldo_car_25;
            private String _saldo_total;
            private String _soma_fxe_pdd_26;
            private String _soma_fxe_pdd_30;
            private String _soma_fxe_pdd_05;
            private String _soma_fxe_pdd_14;
            private String _soma_fxe_pdd_21;
            private String _soma_fxe_pdd_25;
            private String _valor_pagamento;
            private String _valor_ajuste;
            private String _saldo_atual;
            private String _ciclo;
            private String _uf;
            private String _status;
            private String _classe;
            private String _segmento_gerencia;
            private String _gn;
            private String _gv;
            private String _diretor;
            private String _analista_tlf_vivo;
            private String _intragov;
            private String _intercompany;
            private String _feedback_00;
            private String _feedback_01;
            private String _feedback_02;
            private String _feedback_03;
            private String _feedback_04;
            private String _feedback_05;
            private String _pendente_id_analise_conta;
            private String _pendente_data_analise_conta;
            private String _concluido_id_analise_conta;
            private String _concluido_data_analise_conta;
            private String _reaberto_id_analise_conta;
            private String _reaberto_data_analise_conta;
            private String _qtd_reg_agrupado;
            private String _dt_ult_alteracao;
            private String _usuario_atualizacao;
            private String _id_analista;
            private String _id_analista_tmp;
            private String _area_atuacao;
            private String _task_force;
            private String _seg_descr;
            private String _parcelamento;
            private String _escalation;
            private String _conta_bonus;
            private String _obs;
            private String _id_portal_demanda;
            private String _Faixa_Corte;
            private String _Regra_PDD;
            private String _SITUACAO_SERVICO;



            // métodos // contrutor
            public Acordos(
                    String procv
                    , String id
                    , String nome_analista
                    , String nome_analista_tmp
                    , String feedback
                    , String area_ofensora
                    , String tipo_pagto
                    , String dt_pagto
                    , String valor_pagto
                    , String dt_ajuste
                    , String valor_ajustado
                    , String resumo_executivo_acao
                    , String resumo_executivo_problema
                    , String historico_detalhado
                    , String dt_follow_up
                    , String dt_encerramento
                    , String dt_contato
                    , String responsavel
                    , String faixa_fornecedor
                    , String faixa_fecho
                    , String faixa_arrecada_inicial
                    , String faixa_arrecada_atual
                    , String raiz_grupo
                    , String grupo
                    , String raiz
                    , String cnpj
                    , String nome
                    , String nome_cliente
                    , String tipo
                    , String empresa
                    , String conta
                    , String tel
                    , String local
                    , String terminal
                    , String dv
                    , String nrc
                    , String classerv
                    , String titulo
                    , String filial
                    , String lj_cli
                    , String cod_cli
                    , String documento_sap
                    , String doc_fat
                    , String n_doc_de_para_atlys
                    , String nota_fiscal
                    , String venc_atual
                    , String venc_original
                    , String dt_process
                    , String anomes
                    , String dia_vencimento_lote
                    , String numero_lote
                    , String valor_lote
                    , String saldo_car_26
                    , String saldo_car_30
                    , String saldo_car_05
                    , String saldo_car_14
                    , String saldo_car_21
                    , String saldo_car_25
                    , String saldo_total
                    , String soma_fxe_pdd_26
                    , String soma_fxe_pdd_30
                    , String soma_fxe_pdd_05
                    , String soma_fxe_pdd_14
                    , String soma_fxe_pdd_21
                    , String soma_fxe_pdd_25
                    , String valor_pagamento
                    , String valor_ajuste
                    , String saldo_atual
                    , String ciclo
                    , String uf
                    , String status
                    , String classe
                    , String segmento_gerencia
                    , String gn
                    , String gv
                    , String diretor
                    , String analista_tlf_vivo
                    , String intragov
                    , String intercompany
                    , String feedback_00
                    , String feedback_01
                    , String feedback_02
                    , String feedback_03
                    , String feedback_04
                    , String feedback_05
                    , String pendente_id_analise_conta
                    , String pendente_data_analise_conta
                    , String concluido_id_analise_conta
                    , String concluido_data_analise_conta
                    , String reaberto_id_analise_conta
                    , String reaberto_data_analise_conta
                    , String qtd_reg_agrupado
                    , String dt_ult_alteracao
                    , String usuario_atualizacao
                    , String id_analista
                    , String id_analista_tmp
                    , String area_atuacao
                    , String task_force
                    , String seg_descr
                    , String parcelamento
                    , String escalation
                    , String conta_bonus
                    , String obs
                    , String id_portal_demanda
                    , String faixa_corte
                    , String regra_pdd
                    , String situacao_servico


                )
            {
                this._procv = procv;
                this._id = id;
                this._nome_analista = nome_analista;
                this._nome_analista_tmp = nome_analista_tmp;
                this._feedback = feedback;
                this._area_ofensora = area_ofensora;
                this._tipo_pagto = tipo_pagto;
                this._dt_pagto = dt_pagto;
                this._valor_pagto = valor_pagto;
                this._dt_ajuste = dt_ajuste;
                this._valor_ajustado = valor_ajustado;
                this._resumo_executivo_acao = resumo_executivo_acao;
                this._resumo_executivo_problema = resumo_executivo_problema;
                this._historico_detalhado = historico_detalhado;
                this._dt_follow_up = dt_follow_up;
                this._dt_encerramento = dt_encerramento;
                this._dt_contato = dt_contato;
                this._responsavel = responsavel;
                this._faixa_fornecedor = faixa_fornecedor;
                this._faixa_fecho = faixa_fecho;
                this._faixa_arrecada_inicial = faixa_arrecada_inicial;
                this._faixa_arrecada_atual = faixa_arrecada_atual;
                this._raiz_grupo = raiz_grupo;
                this._grupo = grupo;
                this._raiz = raiz;
                this._cnpj = cnpj;
                this._nome = nome;
                this._nome_cliente = nome_cliente;
                this._tipo = tipo;
                this._empresa = empresa;
                this._conta = conta;
                this._tel = tel;
                this._local = local;
                this._terminal = terminal;
                this._dv = dv;
                this._nrc = nrc;
                this._classerv = classerv;
                this._titulo = titulo;
                this._filial = filial;
                this._lj_cli = lj_cli;
                this._cod_cli = cod_cli;
                this._documento_sap = documento_sap;
                this._doc_fat = doc_fat;
                this._n_doc_de_para_atlys = n_doc_de_para_atlys;
                this._nota_fiscal = nota_fiscal;
                this._venc_atual = venc_atual;
                this._venc_original = venc_original;
                this._dt_process = dt_process;
                this._anomes = anomes;
                this._dia_vencimento_lote = dia_vencimento_lote;
                this._numero_lote = numero_lote;
                this._valor_lote = valor_lote;
                this._saldo_car_26 = saldo_car_26;
                this._saldo_car_30 = saldo_car_30;
                this._saldo_car_05 = saldo_car_05;
                this._saldo_car_14 = saldo_car_14;
                this._saldo_car_21 = saldo_car_21;
                this._saldo_car_25 = saldo_car_25;
                this._saldo_total = saldo_total;
                this._soma_fxe_pdd_26 = soma_fxe_pdd_26;
                this._soma_fxe_pdd_30 = soma_fxe_pdd_30;
                this._soma_fxe_pdd_05 = soma_fxe_pdd_05;
                this._soma_fxe_pdd_14 = soma_fxe_pdd_14;
                this._soma_fxe_pdd_21 = soma_fxe_pdd_21;
                this._soma_fxe_pdd_25 = soma_fxe_pdd_25;
                this._valor_pagamento = valor_pagamento;
                this._valor_ajuste = valor_ajuste;
                this._saldo_atual = saldo_atual;
                this._ciclo = ciclo;
                this._uf = uf;
                this._status = status;
                this._classe = classe;
                this._segmento_gerencia = segmento_gerencia;
                this._gn = gn;
                this._gv = gv;
                this._diretor = diretor;
                this._analista_tlf_vivo = analista_tlf_vivo;
                this._intragov = intragov;
                this._intercompany = intercompany;
                this._feedback_00 = feedback_00;
                this._feedback_01 = feedback_01;
                this._feedback_02 = feedback_02;
                this._feedback_03 = feedback_03;
                this._feedback_04 = feedback_04;
                this._feedback_05 = feedback_05;
                this._pendente_id_analise_conta = pendente_id_analise_conta;
                this._pendente_data_analise_conta = pendente_data_analise_conta;
                this._concluido_id_analise_conta = concluido_id_analise_conta;
                this._concluido_data_analise_conta = concluido_data_analise_conta;
                this._reaberto_id_analise_conta = reaberto_id_analise_conta;
                this._reaberto_data_analise_conta = reaberto_data_analise_conta;
                this._qtd_reg_agrupado = qtd_reg_agrupado;
                this._dt_ult_alteracao = dt_ult_alteracao;
                this._usuario_atualizacao = usuario_atualizacao;
                this._id_analista = id_analista;
                this._id_analista_tmp = id_analista_tmp;
                this._area_atuacao = area_atuacao;
                this._task_force = task_force;
                this._seg_descr = seg_descr;
                this._parcelamento = parcelamento;
                this._escalation = escalation;
                this._conta_bonus = conta_bonus;
                this._obs = obs;
                this._id_portal_demanda = id_portal_demanda;
                this._Faixa_Corte = faixa_corte;
                this._Regra_PDD = regra_pdd;
                this._SITUACAO_SERVICO = situacao_servico;


            }

            // métodos 
            public String procv { get { return _procv; } }
            public String id { get { return _id; } }
            public String nome_analista { get { return _nome_analista; } }
            public String nome_analista_tmp { get { return _nome_analista_tmp; } }
            public String feedback { get { return _feedback; } }
            public String area_ofensora { get { return _area_ofensora; } }
            public String tipo_pagto { get { return _tipo_pagto; } }
            public String dt_pagto { get { return _dt_pagto; } }
            public String valor_pagto { get { return _valor_pagto; } }
            public String dt_ajuste { get { return _dt_ajuste; } }
            public String valor_ajustado { get { return _valor_ajustado; } }
            public String resumo_executivo_acao { get { return _resumo_executivo_acao; } }
            public String resumo_executivo_problema { get { return _resumo_executivo_problema; } }
            public String historico_detalhado { get { return _historico_detalhado; } }
            public String dt_follow_up { get { return _dt_follow_up; } }
            public String dt_encerramento { get { return _dt_encerramento; } }
            public String dt_contato { get { return _dt_contato; } }
            public String responsavel { get { return _responsavel; } }
            public String faixa_fornecedor { get { return _faixa_fornecedor; } }
            public String faixa_fecho { get { return _faixa_fecho; } }
            public String faixa_arrecada_inicial { get { return _faixa_arrecada_inicial; } }
            public String faixa_arrecada_atual { get { return _faixa_arrecada_atual; } }
            public String raiz_grupo { get { return _raiz_grupo; } }
            public String grupo { get { return _grupo; } }
            public String raiz { get { return _raiz; } }
            public String cnpj { get { return _cnpj; } }
            public String nome { get { return _nome; } }
            public String nome_cliente { get { return _nome_cliente; } }
            public String tipo { get { return _tipo; } }
            public String empresa { get { return _empresa; } }
            public String conta { get { return _conta; } }
            public String tel { get { return _tel; } }
            public String local { get { return _local; } }
            public String terminal { get { return _terminal; } }
            public String dv { get { return _dv; } }
            public String nrc { get { return _nrc; } }
            public String classerv { get { return _classerv; } }
            public String titulo { get { return _titulo; } }
            public String filial { get { return _filial; } }
            public String lj_cli { get { return _lj_cli; } }
            public String cod_cli { get { return _cod_cli; } }
            public String documento_sap { get { return _documento_sap; } }
            public String doc_fat { get { return _doc_fat; } }
            public String n_doc_de_para_atlys { get { return _n_doc_de_para_atlys; } }
            public String nota_fiscal { get { return _nota_fiscal; } }
            public String venc_atual { get { return _venc_atual; } }
            public String venc_original { get { return _venc_original; } }
            public String dt_process { get { return _dt_process; } }
            public String anomes { get { return _anomes; } }
            public String dia_vencimento_lote { get { return _dia_vencimento_lote; } }
            public String numero_lote { get { return _numero_lote; } }
            public String valor_lote { get { return _valor_lote; } }
            public String saldo_car_26 { get { return _saldo_car_26; } }
            public String saldo_car_30 { get { return _saldo_car_30; } }
            public String saldo_car_05 { get { return _saldo_car_05; } }
            public String saldo_car_14 { get { return _saldo_car_14; } }
            public String saldo_car_21 { get { return _saldo_car_21; } }
            public String saldo_car_25 { get { return _saldo_car_25; } }
            public String saldo_total { get { return _saldo_total; } }
            public String soma_fxe_pdd_26 { get { return _soma_fxe_pdd_26; } }
            public String soma_fxe_pdd_30 { get { return _soma_fxe_pdd_30; } }
            public String soma_fxe_pdd_05 { get { return _soma_fxe_pdd_05; } }
            public String soma_fxe_pdd_14 { get { return _soma_fxe_pdd_14; } }
            public String soma_fxe_pdd_21 { get { return _soma_fxe_pdd_21; } }
            public String soma_fxe_pdd_25 { get { return _soma_fxe_pdd_25; } }
            public String valor_pagamento { get { return _valor_pagamento; } }
            public String valor_ajuste { get { return _valor_ajuste; } }
            public String saldo_atual { get { return _saldo_atual; } }
            public String ciclo { get { return _ciclo; } }
            public String uf { get { return _uf; } }
            public String status { get { return _status; } }
            public String classe { get { return _classe; } }
            public String segmento_gerencia { get { return _feedback; } }
            public String gn { get { return _gn; } }
            public String gv { get { return _gv; } }
            public String diretor { get { return _diretor; } }
            public String analista_tlf_vivo { get { return _analista_tlf_vivo; } }
            public String intragov { get { return _intragov; } }
            public String intercompany { get { return _intercompany; } }
            public String feedback_00 { get { return _feedback_00; } }
            public String feedback_01 { get { return _feedback; } }
            public String feedback_02 { get { return _feedback_02; } }
            public String feedback_03 { get { return _feedback_03; } }
            public String feedback_04 { get { return _feedback_04; } }
            public String feedback_05 { get { return _feedback_05; } }
            public String pendente_id_analise_conta { get { return _pendente_id_analise_conta; } }
            public String pendente_data_analise_conta { get { return _pendente_data_analise_conta; } }
            public String concluido_id_analise_conta { get { return _concluido_id_analise_conta; } }
            public String concluido_data_analise_conta { get { return _concluido_data_analise_conta; } }
            public String reaberto_id_analise_conta { get { return _reaberto_id_analise_conta; } }
            public String reaberto_data_analise_conta { get { return _reaberto_data_analise_conta; } }
            public String qtd_reg_agrupado { get { return _qtd_reg_agrupado; } }
            public String dt_ult_alteracao { get { return _dt_ult_alteracao; } }
            public String usuario_atualizacao { get { return _usuario_atualizacao; } }
            public String id_analista { get { return _id_analista; } }
            public String id_analista_tmp { get { return _id_analista_tmp; } }
            public String area_atuacao { get { return _feedback; } }
            public String task_force { get { return _task_force; } }
            public String seg_descr { get { return _seg_descr; } }
            public String parcelamento { get { return _parcelamento; } }
            public String escalation { get { return _escalation; } }
            public String conta_bonus { get { return _feedback; } }
            public String obs { get { return _obs; } }
            public String id_portal_demanda { get { return _id_portal_demanda; } }
            public String faixa_Corte { get { return _Faixa_Corte; } }
            public String regra_pdd { get { return _Regra_PDD; } }
            public String situacao_servico { get { return _SITUACAO_SERVICO; } }
        }


        static int Main(string[] args) //string[] args
        {
            string sPath = System.IO.Directory.GetCurrentDirectory(); //String sFile = bco.ArquivoCaminho + bco.ArquivoNome;
            List<Acordos> lstCn = new List<Acordos>();
            Banco bco = new Banco();

            if (args.Length == 0)
            {
                System.Console.WriteLine("Por favor entre com o ID de analista");
                return 1;
            }
            //bco.carregarSolicitacao(args[0]);


            // bco.carregarSolicitacao(@"98");
            //bco.Selecao(bco.Solicitacao);
            //bco.arquivoCompactar(sFile, sFile.Substring(0, sFile.Length - 3) + "7z");

            bco.arquivoCriarXml(args[0]);
            //String sFile = sPath + "\\" + bco.ArquivoNome;
            bco.arquivoCompactar(bco.ArquivoNome, bco.ArquivoNome.Substring(0, bco.ArquivoNome.Length - 3) + "7z");


            //#region CRIAR_ARQUIVO

            ////List<List<string>> lstExtracao = new List<List<string>>();
            //List<string> lstRegistro;
            //long contador = 0;
            //long acumulador = 0;


            //// carregar cabecalho
            //List<string> lstCabecalho = new List<string>(); for (int i = 0; i < bco.Rdr.FieldCount; i++) { lstCabecalho.Add(bco.Rdr.GetName(i).ToString()); }
            //Console.WriteLine(@" >>> LISTAR CABECALHOS - OK");

            //// criar arquivo
            //using (XmlWriter writer = XmlWriter.Create(sPath + "\\" + bco.ArquivoNome))
            //{
            //    writer.WriteStartDocument(); writer.WriteStartElement("Registros"); // inicio do documento
            //    while (bco.Rdr.Read()) // listar registros
            //    {
            //        contador++;
            //        acumulador++;
            //        lstRegistro = new List<string>(); // variaveis
            //        writer.WriteStartElement("Registro"); // inicio do elemento

            //        for (int i = 0; i < bco.Rdr.FieldCount; i++)
            //        {
            //            writer.WriteElementString(lstCabecalho[i].ToString(), CleanInvalidXmlChars(bco.Rdr[i].ToString()));
            //        } // escrita do registro

            //        writer.WriteEndElement(); // terminio do elemento
            //        if (contador > 10000) { Console.WriteLine(acumulador + @" >>> registro criados - OK"); contador = 0; } // mostrar evolução do processo 
            //    }
            //    writer.WriteEndElement(); writer.WriteEndDocument();
            //}
            //Console.WriteLine(@" >>> CRIAR ARQUIVO - OK");

            //#endregion


            //List<string> lstCabecalho = new List<string>();
            //for (int i = 0; i < bco.Rdr.FieldCount; i++)
            //{
            //    lstCabecalho.Add(bco.Rdr.GetName(i).ToString());
            //}

            //using (XmlWriter writer = XmlWriter.Create(bco.ArquivoNome)) // criar arquivo
            //{
            //    writer.WriteStartDocument(); writer.WriteStartElement("Registros"); // inicio do documento

            //    while (bco.Rdr.Read()) // listar registros
            //    {
            //        writer.WriteStartElement("Registro"); // inicio do elemento
            //        for (int x = 0; x < bco.Rdr.FieldCount; x++)
            //        {
            //            writer.WriteElementString(lstCabecalho[x].ToString(), CleanInvalidXmlChars(bco.Rdr[x].ToString()));
            //        } // escrita do registro

            //        writer.WriteEndElement(); // terminio do elemento
            //    }
            //    writer.WriteEndElement();
            //    writer.WriteEndDocument();
            //}



            ////// ### ( criar arquivo ) ########################################################################

            //using (XmlWriter writer = XmlWriter.Create(sPath + "\\VPE_FIXA_SIM.xml"))
            //{

            //    writer.WriteStartDocument();
            //    writer.WriteStartElement("Registros");

            //    foreach (var registro in lstExtracao)
            //    {
            //        writer.WriteStartElement("Registro");
            //        for (int i = 0; i < registro.Count; i++)
            //        {
            //            writer.WriteElementString(lstCabecalho[i].ToString(), CleanInvalidXmlChars(registro[i].ToString()));
            //        }
            //        writer.WriteEndElement();
            //    }

            //    writer.WriteEndElement();
            //    writer.WriteEndDocument();
            //}
            //Console.WriteLine(@" >>> CRIAR ARQUIVO - OK");
            ////// ### ( criar arquivo ) ########################################################################







            //Program carregarDados = new Program();
            //carregarDados.CarregarAcordos(lstCn, bco.Solicitacao);


            //#region Variaveis
            ////long contador = 0;
            //////172.16.0.11/siscob/ACORDO

            //// bco.NomeArquivo
            //// "c:/tmp/60872173.xml"
            ////string tmpPath = "c:/tmp/" + bco.ArquivoNome;
            ////string tmpPath = bco.ArquivoCaminho + bco.ArquivoNome;

            ////string tmpPath = bco.ArquivoNome;

            //#endregion



            bco.Fechar();
            return 1;

        }



        public static String TestString(string s)
        {
            if (String.IsNullOrEmpty(s))
                return "";
            else
                return s;
        }


        public static string CleanInvalidXmlChars(string text)
        {
            // From xml spec valid chars: 
            // #x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD] | [#x10000-#x10FFFF]     
            // any Unicode character, excluding the surrogate blocks, FFFE, and FFFF. 
            string re = @"[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD\x10000-x10FFFF]";
            return Regex.Replace(text, re, "");
        }

    }
}

--=====================================================================================================================================
-- P�s Valida��o Fixa
-- Faixa Arrecada X Tipo
--=====================================================================================================================================

SELECT 
		  P.TIPO
		 ,SUM(ISNULL(P.[A FATURAR],0))			AS [A FATURAR]
		 ,SUM(ISNULL(P.[00 - A VENCER],0))		AS [00 - A VENCER]	
		 ,SUM(ISNULL(P.[01 - DE 01 A 30],0))	AS [01 - DE 01 A 30]
		 ,SUM(ISNULL(P.[02 - DE 31 A 75],0))	AS [02 - DE 31 A 75]
		 ,SUM(ISNULL(P.[03 - DE 76 A 105],0))	AS [03 - DE 76 A 105]
		 ,SUM(ISNULL(P.[04 - DE 106 A 365],0))	AS [04 - DE 106 A 365]
		 ,SUM(ISNULL(P.[05 - MAIOR 365],0))		AS [05 - MAIOR 365]	
FROM
		(
			SELECT 
						
						T.TIPO
					,SUM(T.SALDO_CAR_21)			AS SALDO_CAR
					,T.FAIXA_ARRECADA_ATUAL			AS AGING
			FROM
								[DB_SISCOB].[APP_EXCEL].[VW_CONSUMO_CONSOLIDADO_ANALISTA]	T
			WHERE 
					AREA_ATUACAO = 'FIXA'					
			GROUP BY
					 T.TIPO 
					,T.FAIXA_ARRECADA_ATUAL
		)

		 AS R
			Pivot (SUM(R.SALDO_CAR) FOR R.AGING IN (
													 [A FATURAR]
													,[00 - A VENCER]
													,[01 - DE 01 A 30]
													,[02 - DE 31 A 75]
													,[03 - DE 76 A 105]
													,[04 - DE 106 A 365]
													,[05 - MAIOR 365]
													)
	) P

GROUP BY
	 P.TIPO


--=====================================================================================================================================
-- P�s Valida��o Movel
-- Faixa Arrecada X Fornecedor
--=====================================================================================================================================
SELECT 
	P.FORNECEDOR
	,SUM(ISNULL(P.[A FATURAR],0))			AS [A FATURAR]
	,SUM(ISNULL(P.[00 - A VENCER],0))		AS [00 - A VENCER]	
	,SUM(ISNULL(P.[01 - DE 01 A 30],0))	AS [01 - DE 01 A 30]
	,SUM(ISNULL(P.[02 - DE 31 A 75],0))	AS [02 - DE 31 A 75]
	,SUM(ISNULL(P.[03 - DE 76 A 105],0))	AS [03 - DE 76 A 105]
	,SUM(ISNULL(P.[04 - DE 106 A 365],0))	AS [04 - DE 106 A 365]
	,SUM(ISNULL(P.[05 - MAIOR 365],0))		AS [05 - MAIOR 365]
	
FROM
		(
			SELECT 
						
					 T.FORNECEDOR
					,SUM(T.SALDO_CAR_21)		AS SALDO_CAR
					,T.FAIXA_ARRECADA_ATUAL			AS AGING
			FROM
								[DB_SISCOB].[APP_EXCEL].[VW_CONSUMO_CONSOLIDADO_ANALISTA]	T
			WHERE 
					AREA_ATUACAO = 'MOVEL'	
			GROUP BY
					 T.FORNECEDOR 
					,T.FAIXA_ARRECADA_ATUAL
		)

		AS R
			Pivot (SUM(R.SALDO_CAR) FOR R.AGING IN (
													 [A FATURAR]
													,[00 - A VENCER]
													,[01 - DE 01 A 30]
													,[02 - DE 31 A 75]
													,[03 - DE 76 A 105]
													,[04 - DE 106 A 365]
													,[05 - MAIOR 365]
													)
	) P

	GROUP BY
			 P.FORNECEDOR

--====================================================================================================================================




--=====================================================================================================================================
-- P�s Valida��o Fixa
-- Seg_Descr X Tipo
--=====================================================================================================================================


SELECT 
		  P.TIPO
		 ,SUM(ISNULL(P.[VPE],0))			AS [VPE]
		 ,SUM(ISNULL(P.[VPE-GOV],0))		AS [VPE-GOV]	
		 ,SUM(ISNULL(P.[VPG-TOP],0))		AS [VPG-TOP]
		 ,SUM(ISNULL(P.[VPG-TOP-GOV],0))	AS [VPG-TOP-GOV]
		 ,SUM(ISNULL(P.[VPK],0))			AS [VPK]
		 ,SUM(ISNULL(P.[VPK-GOV],0))		AS [VPK-GOV]
		 ,SUM(ISNULL(P.[CORPORATIVO],0))	AS [CORPORATIVO]
	

		FROM
			
			(
				SELECT 
						
						 T.TIPO
						,SUM(T.SALDO_CAR_21)			AS SALDO_CAR
						,T.SEG_DESCR				
				FROM
								  [DB_SISCOB].[APP_EXCEL].[VW_CONSUMO_CONSOLIDADO_ANALISTA]	T
			WHERE 
					AREA_ATUACAO = 'FIXA'	
				
						
				GROUP BY
						-- C.RAIZ_CPF_CNPJ
						 T.TIPO 
						,T.SEG_DESCR
			)

			 AS R
					Pivot (SUM(R.SALDO_CAR) FOR R.SEG_DESCR IN (
															 [VPE]
															,[VPE-GOV]
															,[VPG-TOP]
															,[VPG-TOP-GOV]
															,[VPK]
															,[VPK-GOV]
															,[CORPORATIVO]
															)
															
	) P

	GROUP BY
			 P.TIPO


--================================================================================================================================

--=====================================================================================================================================
-- P�s Valida��o Movel
-- Seg_Descr X Fornecedor
--=====================================================================================================================================

SELECT 
		  P.FORNECEDOR
		 ,SUM(ISNULL(P.[VPE],0))			AS [VPE]
		 ,SUM(ISNULL(P.[VPE-GOV],0))		AS [VPE-GOV]	
		 ,SUM(ISNULL(P.[VPG-TOP],0))		AS [VPG-TOP]
		 ,SUM(ISNULL(P.[VPG-TOP-GOV],0))	AS [VPG-TOP-GOV]
		 ,SUM(ISNULL(P.[VPK],0))			AS [VPK]
	
		FROM
			
			(
				SELECT 
						
						 T.FORNECEDOR
						,SUM(T.SALDO_CAR_21)			AS SALDO_CAR
						,T.SEG_DESCR				
				FROM
								[DB_SISCOB].[APP_EXCEL].[VW_CONSUMO_CONSOLIDADO_ANALISTA]	T
				WHERE 
						AREA_ATUACAO = 'MOVEL'	
						
				GROUP BY
						-- C.RAIZ_CPF_CNPJ
						 T.FORNECEDOR 
						,T.SEG_DESCR
			)

			 AS R
					Pivot (SUM(R.SALDO_CAR) FOR R.SEG_DESCR IN (
															 [VPE]
															,[VPE-GOV]
															,[VPG-TOP]
															,[VPG-TOP-GOV]
															,[VPK]
															)
															


	) P

	GROUP BY
			 P.FORNECEDOR

USE [DB_SISCOB]
GO

--================================================================================================================
-- Procedimento para validar os casos que est�o em andamento e atualizar para atrasado
-- Quando DT_FOLLOW > que a data de hoje
--=================================================================================================================
UPDATE CS SET 
			CS.ID_STATUS_ESCALATION = 4

FROM	
				[CONSOLIDADO].[TB_CONSUMO_SISCOB]	CS
	INNER JOIN	[CONSOLIDADO].[TB_HISTORICO]		H	ON CS.ID_HISTORICO_ATUAL = H.ID
WHERE
		CS.ID_STATUS_ESCALATION IN (2,3,NULL)
	AND	(H.DT_FOLLOW < GETDATE() OR H.DT_FOLLOW IS NULL) 
--=================================================================================================================

--=================================================================================================================
-- Procedimento que valida os prechimentos por fatura que foram apenas trocados as data Folow e mantidos o feedback
-- 3 etapas de execu��o
--=================================================================================================================

-- ## 1 Etapa
--====================================
-- Buscar a informa��o atual da fatura
SELECT 
		  H.ID
		 ,H.ID_CONSOLIDADO
		 ,H.ID_FOCO_FEEDBACK
		 ,H.DT_FOLLOW
		 ,H.ID_ANALISTA
		 ,H.TIME_STAMP
		 
INTO #TMP1
FROM	
				[CONSOLIDADO].[TB_CONSUMO_SISCOB]	CS
	INNER JOIN	[CONSOLIDADO].[TB_HISTORICO]		H	ON CS.ID_HISTORICO_ATUAL = H.ID
WHERE
	CS.ID_STATUS_ESCALATION = 2
ORDER BY
	H.ID DESC;
--=================================================

--==================================================
-- ## 2 Etapa
-- Buscar os preenchimentos das faturas da 1 etapa
-- por�m que n�o sejam o preenchimento atual

SELECT
	 H.ID
	,H.ID_CONSOLIDADO
	,H.ID_FOCO_FEEDBACK
	,H.DT_FOLLOW
	,H.ID_ANALISTA
	,H.TIME_STAMP
	
INTO #TMP2
FROM
			   [CONSOLIDADO].[TB_HISTORICO] H
	INNER JOIN #TMP1							ON H.ID_CONSOLIDADO = #TMP1.ID_CONSOLIDADO
WHERE
	H.ID NOT IN
	(
		SELECT 
			ID
		FROM
			#TMP1
	)
ORDER BY H.ID DESC; 
--==================================================


--=============================================================================================
-- ## 3 Etapa
-- Atualiza��o do Escalation aonde as faturas permanessam o mesmo feedback e td follow alterada
--=============================================================================================
UPDATE CS
			SET 
				CS.ID_STATUS_ESCALATION = 3

FROM
				[CONSOLIDADO].[TB_CONSUMO_SISCOB]	CS
	INNER JOIN  (
					SELECT 
						 #TMP1.ID 
						,#TMP1.ID_CONSOLIDADO AS ID_CONSOLIDADO1
						,#TMP1.ID_FOCO_FEEDBACK
						,#TMP1.ID_ANALISTA
						,#TMP1.DT_FOLLOW
						,MAX(#TMP2.ID) ID_2
						,#TMP2.ID_CONSOLIDADO AS ID_CONSOLIDADO2
					FROM
										#TMP1
							INNER JOIN  #TMP2 ON #TMP1.ID_CONSOLIDADO = #TMP2.ID_CONSOLIDADO
					GROUP BY
							 #TMP1.ID
							,#TMP1.ID_CONSOLIDADO
							,#TMP2.ID_CONSOLIDADO
							,#TMP1.ID_FOCO_FEEDBACK
							,#TMP1.ID_ANALISTA
							,#TMP1.DT_FOLLOW

				) H ON CS.ID_CONSOLIDADO = H.ID_CONSOLIDADO1
		INNER JOIN [CONSOLIDADO].[TB_HISTORICO] HT ON HT.ID = H.ID_2
WHERE
			H.ID_FOCO_FEEDBACK	= HT.ID_FOCO_FEEDBACK
		AND H.ID_ANALISTA		= HT.ID_ANALISTA
		AND H.DT_FOLLOW			> HT.DT_FOLLOW
--=================================================================================================

Drop Table #TMP1;
Drop Table #TMP2;

--=====================================================================================================================================
-- Pr� Valida��o Fixa
-- Faixa Arrecada X Tipo
--=====================================================================================================================================

SELECT 
		  P.TIPO
		 ,SUM(ISNULL(P.[7],0))		AS [A FATURAR]
		 ,SUM(ISNULL(P.[1],0))		AS [00 - A VENCER]	
		 ,SUM(ISNULL(P.[2],0))		AS [01 - DE 01 A 30]
		 ,SUM(ISNULL(P.[3],0))		AS [02 - DE 31 A 75]
		 ,SUM(ISNULL(P.[4],0))		AS [03 - DE 76 A 105]
		 ,SUM(ISNULL(P.[5],0))		AS [04 - DE 106 A 365]
		 ,SUM(ISNULL(P.[6],0))		AS [05 - MAIOR 365]	
FROM
		(
			SELECT 
						
						 TP.TIPO
					,SUM(T.SALDO_CAR)			AS SALDO_CAR
					,T.ID_FX_ARRECADA			AS AGING
			FROM
									[DB_SISCOB].[FILE_CAR].[TB_TRATAMENTO_FIXA]	T
						INNER JOIN	[DB_SISCOB].[AUXILIAR].[TB_TIPO] TP ON T.ID_TIPO = TP.ID
			WHERE 
					T.OK = 1						
			GROUP BY
						 TP.TIPO 
						,T.ID_FX_ARRECADA
		)

		 AS R
			Pivot (SUM(R.SALDO_CAR) FOR R.AGING IN (
													 [7]
													,[1]
													,[2]
													,[3]
													,[4]
													,[5]
													,[6]
													)
	) P

GROUP BY
	 P.TIPO
--====================================================================================================================================
			 



--=====================================================================================================================================
-- Pr� Valida��o Movel
-- Faixa Arrecada X Fornecedor
--=====================================================================================================================================
SELECT 
	P.FORNECEDOR
	,SUM(ISNULL(P.[7],0))		AS [A FATURAR]
	,SUM(ISNULL(P.[1],0))		AS [00 - A VENCER]	
	,SUM(ISNULL(P.[2],0))		AS [01 - DE 01 A 30]
	,SUM(ISNULL(P.[3],0))		AS [02 - DE 31 A 75]
	,SUM(ISNULL(P.[4],0))		AS [03 - DE 76 A 105]
	,SUM(ISNULL(P.[5],0))		AS [04 - DE 106 A 365]
	,SUM(ISNULL(P.[6],0))		AS [05 - MAIOR 365]	
	
FROM
		(
			SELECT 
						
					 T.FORNECEDOR
					,SUM(T.SALDO_CAR)			AS SALDO_CAR
					,T.ID_FX_ARRECADA			AS AGING
			FROM
								[DB_SISCOB].[FILE_CAR].[TB_TRATAMENTO_MOVEL]	T
					
			WHERE 
					T.OK = 1	
			GROUP BY
					 T.FORNECEDOR 
					,T.ID_FX_ARRECADA
		)

		AS R
			Pivot (SUM(R.SALDO_CAR) FOR R.AGING IN (
													 [7]
													,[1]
													,[2]
													,[3]
													,[4]
													,[5]
													,[6]
													)
	) P

	GROUP BY
			 P.FORNECEDOR

--====================================================================================================================================


--=====================================================================================================================================
-- Pr� Valida��o Fixa
-- Seg_Descr X Tipo
--=====================================================================================================================================


SELECT 
		  P.TIPO
		 ,SUM(ISNULL(P.[VPE],0))			AS [VPE]
		 ,SUM(ISNULL(P.[VPE-GOV],0))		AS [VPE-GOV]	
		 ,SUM(ISNULL(P.[VPG-TOP],0))		AS [VPG-TOP]
		 ,SUM(ISNULL(P.[VPG-TOP-GOV],0))	AS [VPG-TOP-GOV]
		 ,SUM(ISNULL(P.[VPK],0))			AS [VPK]
		 ,SUM(ISNULL(P.[VPK-GOV],0))		AS [VPK-GOV]
		 ,SUM(ISNULL(P.[CORPORATIVO],0))	AS [CORPORATIVO]
	

		FROM
			
			(
				SELECT 
						
						 TP.TIPO
						,SUM(T.SALDO_CAR)			AS SALDO_CAR
						,F.SEG_DESCR				
				FROM
								   [DB_SISCOB].[FILE_CAR].[TB_TRATAMENTO_FIXA]	T
						INNER JOIN [DB_SISCOB].[FILE_CAR].[TB_CAR_FIXA_IMPORT] F ON T.ID_IMPORT_FIXA = F.ID
						INNER JOIN [DB_SISCOB].[AUXILIAR].[TB_TIPO] TP ON T.ID_TIPO = TP.ID
				WHERE 
						--V.[AREA_ATUACAO] = 'MOVEL'
						--AND V.RAIZ_GRUPO = '4004144280'
						T.OK = 1
						
				GROUP BY
						-- C.RAIZ_CPF_CNPJ
						 TP.TIPO 
						,F.SEG_DESCR
			)

			 AS R
					Pivot (SUM(R.SALDO_CAR) FOR R.SEG_DESCR IN (
															 [VPE]
															,[VPE-GOV]
															,[VPG-TOP]
															,[VPG-TOP-GOV]
															,[VPK]
															,[VPK-GOV]
															,[CORPORATIVO]
															)
															
	) P

	GROUP BY
			 P.TIPO


--================================================================================================================================

--=====================================================================================================================================
-- Pr� Valida��o Movel
-- Seg_Descr X Fornecedor
--=====================================================================================================================================

SELECT 
		  P.FORNECEDOR
		 ,SUM(ISNULL(P.[VPE],0))			AS [VPE]
		 ,SUM(ISNULL(P.[VPE-GOV],0))		AS [VPE-GOV]	
		 ,SUM(ISNULL(P.[VPG-TOP],0))		AS [VPG-TOP]
		 ,SUM(ISNULL(P.[VPG-TOP-GOV],0))	AS [VPG-TOP-GOV]
		 ,SUM(ISNULL(P.[VPK],0))			AS [VPK]
	
		FROM
			
			(
				SELECT 
						
						 T.FORNECEDOR
						,SUM(T.SALDO_CAR)			AS SALDO_CAR
						,F.SEG_DESCR				
				FROM
								   [DB_SISCOB].[FILE_CAR].[TB_TRATAMENTO_MOVEL]	T
						INNER JOIN [DB_SISCOB].[FILE_CAR].[TB_CAR_MOVEL_IMPORT] F ON T.ID_IMPORT_MOVEL = F.ID
				WHERE 
						--V.[AREA_ATUACAO] = 'MOVEL'
						--AND V.RAIZ_GRUPO = '4004144280'
						T.OK = 1
						
				GROUP BY
						-- C.RAIZ_CPF_CNPJ
						 T.FORNECEDOR 
						,F.SEG_DESCR
			)

			 AS R
					Pivot (SUM(R.SALDO_CAR) FOR R.SEG_DESCR IN (
															 [VPE]
															,[VPE-GOV]
															,[VPG-TOP]
															,[VPG-TOP-GOV]
															,[VPK]
															)
															


	) P

	GROUP BY
			 P.FORNECEDOR

			 


	
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Text.RegularExpressions;

namespace exportAcordo
{
    class Program
    {
        static void Main(string[] args)
        {

            Banco bco = new Banco();
            bco.carregarSolicitacao(@"57");
            bco.arquivoCriarXml(bco.Solicitacao,bco.ArquivoNome);
            //bco.arquivoCompactar(bco.ArquivoCaminho + "\\" + bco.ArquivoNome, bco.ArquivoCaminho + "\\" + bco.ArquivoNome.Substring(0, bco.ArquivoNome.Length - 3) + "7z");


            //List<string> lstRegistro;
            //long contador = 0;
            //long acumulador = 0;

            //string sPath = System.IO.Directory.GetCurrentDirectory();
            //string sSQL = "SELECT top 100 * FROM [APP_EXCEL].[VW_CONSUMO_CONSOLIDADO_ACORDO_COM_FILTROS] WHERE RAIZ_GRUPO = '4040432544'  and ID_TIPO IN (1,2,4,5,9)";

            //Banco bco = new Banco();
            //bco.Selecao(sSQL);

            //// carregar cabecalho
            //List<string> lstCabecalho = new List<string>(); for (int i = 0; i < bco.Rdr.FieldCount; i++) { lstCabecalho.Add(bco.Rdr.GetName(i).ToString()); }
            //Console.WriteLine(@" >>> LISTAR CABECALHOS - OK");

            //// criar arquivo
            //using (XmlWriter writer = XmlWriter.Create(sPath + "\\4040432544.xml"))
            //{
            //    writer.WriteStartDocument(); writer.WriteStartElement("Registros"); // inicio do documento
            //    while (bco.Rdr.Read()) // listar registros
            //    {
            //        contador++; acumulador++; lstRegistro = new List<string>(); // variaveis
            //        writer.WriteStartElement("Registro"); // inicio do elemento

            //        for (int i = 0; i < bco.Rdr.FieldCount; i++)
            //        {
            //            writer.WriteElementString(lstCabecalho[i].ToString(), CleanInvalidXmlChars(bco.Rdr[i].ToString()));
            //        } // escrita do registro

            //        writer.WriteEndElement(); // terminio do elemento
            //        if (contador > 10000) { Console.WriteLine(acumulador + @" >>> registro criados - OK"); contador = 0; } // mostrar evolução do processo 
            //    }
            //    writer.WriteEndElement(); writer.WriteEndDocument();
            //}
            //Console.WriteLine(@" >>> CRIAR ARQUIVO - OK");


        }

        public static string CleanInvalidXmlChars(string text)
        {
            // From xml spec valid chars: 
            // #x9 | #xA | #xD | [#x20-#xD7FF] | [#xE000-#xFFFD] | [#x10000-#x10FFFF]     
            // any Unicode character, excluding the surrogate blocks, FFFE, and FFFF. 
            string re = @"[^\x09\x0A\x0D\x20-\xD7FF\xE000-\xFFFD\x10000-x10FFFF]";
            return Regex.Replace(text, re, "");
        }

    }
}

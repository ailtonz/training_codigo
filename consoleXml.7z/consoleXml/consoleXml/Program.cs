﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Xml;
using System.IO;

using System.Data;
using System.Data.SqlClient;


namespace consoleXml
{
    class Program
    {

        string sFilePath = @"C:/tmp/Agenda.xml";

        static void Main(string[] args)
        {
            //carregarcontato();

            Program rd = new Program();
            rd.CarregarTitulo();

            Program Contato = new Program();
            Contato.CriarContato();

            Console.ReadKey();

        }

        private void exportDados() {

            SqlDataReader rdr = null;
            SqlConnection conn = new SqlConnection("Server=TLF-PRD-WBD04.cloudapp.net;Database=db_SISCOB;User ID=a.dasilva;Password=41L70N!$");
            SqlCommand cmd = new SqlCommand("SELECT [DESCRICAO] ,[DESCRICAO_02] ,[DESCRICAO_03]  FROM [DB_SISCOB].[ADM].[TB_APP_CONTROLE]  WHERE [TIPO] = 'LIMPAR_DIRETORIOS' ", conn);

            try
            {
                // open the connection
                conn.Open();

                // 1. get an instance of the SqlDataReader
                rdr = cmd.ExecuteReader();

                // 2. print necessary columns of each  record
                while (rdr.Read())
                {
                    //// get the results of each column
                    //string diretorio = (string)rdr["DESCRICAO"];
                    //string tipo = (string)rdr["DESCRICAO_02"];
                    //string permanencia = (string)rdr["DESCRICAO_03"];

                    //Diretorio dir = new Diretorio(diretorio, tipo, Convert.ToInt32(permanencia));
                    //dir.Limpar();

                }
                Console.ReadKey();// enter
                //Console.ReadLine();// entrada de dados

            }

            finally
            {
                // 3. close the reader
                if (rdr != null)
                {
                    rdr.Close();
                }

                // close the connection
                if (conn != null)
                {
                    conn.Close();
                }
            }
        
        
        }

        private string CarregarTitulo()
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(sFilePath);
            XmlNode noTitulo = xmlDocument.SelectSingleNode("/agenda/titulo");
            return noTitulo.InnerText;
        }

        private void CriarContato()
        {
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(sFilePath);

            XmlAttribute atributoId = xmlDocument.CreateAttribute("id");
            atributoId.Value = "27497483830";

            XmlAttribute atributoNome = xmlDocument.CreateAttribute("nome");
            atributoNome.Value = "Ailton Zacarias";

            XmlAttribute atributoIdade = xmlDocument.CreateAttribute("idade");
            atributoIdade.Value = "27";


            XmlAttribute atributoIdade2 = xmlDocument.CreateAttribute("idade2");
            atributoIdade2.Value = "28";

            XmlNode novoContato = xmlDocument.CreateElement("contato");
            novoContato.Attributes.Append(atributoId);
            novoContato.Attributes.Append(atributoNome);
            novoContato.Attributes.Append(atributoIdade);
            novoContato.Attributes.Append(atributoIdade2);
            XmlNode contatos = xmlDocument.SelectSingleNode("/agenda/contatos");
            contatos.AppendChild(novoContato);
            xmlDocument.Save(@"C:\tmp\Agenda.xml");

        }







    }
}
